library(phyloseq)
library(parallel)
library(plotROC)
library(ggplot2)
data("GlobalPatterns")


# real fecal data
FecalReal <- subset_samples(GlobalPatterns, SampleType=="Feces")
FecalMat <- as(otu_table(FecalReal), "matrix")
taxa <- as(tax_table(FecalReal), "matrix")
taxa[is.na(taxa)] <- "xxx"
taxa <- apply(taxa, 1, paste, collapse = ";")
FecalMat <- aggregate(FecalMat ~ taxa, FUN = sum)
row.names(FecalMat) <- FecalMat$taxa
FecalMat <- as.matrix(FecalMat[,-1])

# Create the rowsum version (multinomial)
FecalMatRS <- rowSums(FecalMat)
FecalMatRS <- FecalMatRS[FecalMatRS >= 10]
FecalMatRS <- matrix(FecalMatRS, nrow=length(FecalMatRS), dimnames = list(names(FecalMatRS)))

## Simulation fucntion
# D: 0/1 ground truth
# mn: multinominal matrix
# N: sample size per group
# ES: a data.frame giving a set of effect sizes and the propotion of features each of the effect size will be applied to
# s: variations of effect size for the second dataset, when D = 1, i.e., similar but not identical effects
# overlap: the propotion of the features in the second dataset that can be found in the first.
simSTARMAPs <- function(D, mn, N, ES,  s, overlap, source.data = GlobalPatterns){
  # realistic library sizes
  NL <- sample(phyloseq::sample_sums(source.data), size = N * 4, replace = TRUE)
  # Simulate the NULL
  nullmat <- sapply(NL, function(NL, mn){
    table(sample(rownames(mn), NL, replace=TRUE, prob = mn))[rownames(mn)]
  }, mn)
  nullmat[is.na(nullmat)] <- 0L
  rownames(nullmat) <- rownames(mn)
  colnames(nullmat) <- make.names(1:ncol(nullmat))
  
  # Apply "effect" to random rows
  ds1 <- nullmat[, 1:(N*2)]
  ds2 <- nullmat[, -(1:(N*2))]
  
  meta1 <- data.frame(samples = colnames(ds1), groups = rep(c("grp1", "grp2"), each = N))
  meta2 <- data.frame(samples = colnames(ds2), groups = rep(c("grp1", "grp2"), each = N))

  
  nf <- nrow(nullmat)
  EffectSize <- rep(ES$es, round(nf * ES$prop, 0))
  ne <- length(EffectSize)
  
  effectcols = 1:N
  effectrows1 <- sample(1:nf, ne)
  
  ds1[effectrows1, effectcols] <- EffectSize * ds1[effectrows1, effectcols]
  
  # ture positieve: same features with similar effect sizes
  # true negative: different set of features
  if(D == 1) effectrows2 <- effectrows1 else
    effectrows2 <- sample((1:nf)[-effectrows1], ne)
  
  ds2[effectrows2, effectcols] <- EffectSize * (2^rnorm(ne, 0, s)) * ds2[effectrows2, effectcols]
  
  # change overlaped features by adding "XX" to a subset of feature names 
  if(overlap < 1){
    # number of features need to change names
    nnof <- round((1 - overlap) * nf, 0)
    change <- sample(1:nf, nnof)
    rownames(ds2)[change] <- paste0("XX", rownames(ds2)[change])
  }
  
  source("STARMAPs_v1_one-level.R")
  cps <- starmaps(ds1, meta1, "groups", ds2, meta2, "groups", nperm = 3000)
  res <- summary.starmaps(cps)
  res$D <- D

  return(res)
  
}


# Effect sizes
# used a list of data.frames to allow for mixed effect sizes in a dataset, if needed.
ESlist <- list(data.frame(es = 2, prop = 0.05),
               data.frame(es = 8, prop = 0.05), 
               data.frame(es = 32, prop = 0.05),
               data.frame(es = 128, prop = 0.05))

set.seed(20181023)
Nsim = 2000


for(l in 1:length(ESlist)){
  ES <- ESlist[[l]]
  tag <- paste0("ES", ES[1,1])
  
  ### simulation 1: effects of sample size
  sim1 <- list()
  N <- c(8, 6, 4)
  for (i in 1:length(N)){
    n <- N[i]
    D <- rbinom(Nsim, size = 1, prob = 0.5)
    cl <- makeCluster(20, type="PSOCK")
    sim1.res0 <- parLapply(cl, D, simSTARMAPs, mn = FecalMatRS, N = n, ES = ES,  s = 0, overlap = 1, source.data = GlobalPatterns)
    stopCluster(cl);rm(cl)
    
    sim1.res <- do.call(rbind, sim1.res0)
    sim1.res$N <- n
    sim1[[i]] <- sim1.res
  }
  
  sim1 <- do.call(rbind, sim1)
  sim1$N <- factor(sim1$N)
  
  pdf(paste0("roc_sim1_N_", tag,".pdf"), 3.5, 3.5)
  sp1<- ggplot(sim1, aes(d = D, m = omnibus.Pval, color = N)) + 
    geom_roc(labelsize = 2.5, increasing = FALSE, 
             cutoffs.at = c(0.05, 0.1, 0.2), cutoff.labels = c(0.05, 0.1, 0.2),
             size = 0.4, pointsize = 0.4) + 
    style_roc() + theme(aspect.ratio = 1, axis.text.x = element_text(angle = -45))
  
  print(sp1)
  dev.off()
  
  write.csv(sim1, paste0("roc_sim1_N_", tag,".csv"), row.names = F)
  
  ### Simulation 2: effects of the variance to the effect sizes
  sim2 <- list()
  Ss <- c(0.1, 0.5, 1, 2)
  for (i in 1:length(Ss)){
    s <- Ss[i]
    D <- rbinom(Nsim, size = 1, prob = 0.5)
    cl <- makeCluster(20, type="PSOCK")
    sim2.res0 <- parLapply(cl, D, simSTARMAPs, mn = FecalMatRS, N = 6, ES = ES,  s = s, overlap = 1, source.data = GlobalPatterns)
    stopCluster(cl);rm(cl)
    
    sim2.res <- do.call(rbind, sim2.res0)
    sim2.res$s <- s
    sim2[[i]] <- sim2.res
  }
  
  sim2 <- do.call(rbind, sim2)
  sim2$s <- factor(sim2$s)
  
  pdf(paste0("roc_sim2_s_", tag,".pdf"), 3.5, 3.5)
  sp2 <- ggplot(sim2, aes(d = D, m = omnibus.Pval, color = s)) + 
    geom_roc(labelsize = 2.5, increasing = FALSE, 
             cutoffs.at = c(0.05, 0.1, 0.2), cutoff.labels = c(0.05, 0.1, 0.2),
             size = 0.4, pointsize = 0.4) + 
    style_roc() + theme(aspect.ratio = 1, axis.text.x = element_text(angle = -45))
  
  print(sp2)
  dev.off()
  
  write.csv(sim2, paste0("roc_sim2_s_", tag,".csv"), row.names = F)
  
  
  ### Simulation 3: effects of overlaping features
  sim3 <- list()
  OP <- c(0.8, 0.6, 0.4, 0.2)
  for (i in 1:length(OP)){
    o <- OP[i]
    D <- rbinom(Nsim, size = 1, prob = 0.5)
    cl <- makeCluster(20, type="PSOCK")
    sim3.res0 <- parLapply(cl, D, simSTARMAPs, mn = FecalMatRS, N = 6, ES = ES,  s = 1, overlap = o, source.data = GlobalPatterns)
    stopCluster(cl);rm(cl)
    
    sim3.res <- do.call(rbind, sim3.res0)
    sim3.res$overlap <- o
    sim3[[i]] <- sim3.res
  }
  
  sim3 <- do.call(rbind, sim3)
  sim3$overlap <- factor(sim3$overlap)
  
  pdf(paste0("roc_sim3_overlap_", tag,".pdf"), 3.5, 3.5)
  sp3 <- ggplot(sim3, aes(d = D, m = omnibus.Pval, color = overlap)) + 
    geom_roc(labelsize = 2.5, increasing = FALSE, 
             cutoffs.at = c(0.05, 0.1, 0.2), cutoff.labels = c(0.05, 0.1, 0.2),
             size = 0.4, pointsize = 0.4) + 
    style_roc() + theme(aspect.ratio = 1, axis.text.x = element_text(angle = -45))
  
  print(sp3)
  dev.off()
  
  write.csv(sim3, paste0("roc_sim3_overlap_", tag,".csv"), row.names = F)
  
}
